<div class="form-field">
    <label for="wp2023_taxonomy_meta_field">Hình ảnh</label>
    <input type="text" id="image" name="image">
</div>